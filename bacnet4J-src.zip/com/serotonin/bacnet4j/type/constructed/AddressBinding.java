/*
 * ============================================================================
 * GNU Lesser General Public License
 * ============================================================================
 *
 * Copyright (C) 2006-2009 Serotonin Software Technologies Inc. http://serotoninsoftware.com
 * @author Matthew Lohbihler
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307, USA.
 */
package com.serotonin.bacnet4j.type.constructed;

import com.serotonin.bacnet4j.exception.BACnetException;
import com.serotonin.bacnet4j.type.primitive.ObjectIdentifier;
import com.serotonin.util.queue.ByteQueue;

public class AddressBinding extends BaseType {
    private static final long serialVersionUID = -3619507415957976531L;
    private final ObjectIdentifier deviceObjectIdentifier;
    private final Address deviceAddress;

    public AddressBinding(ObjectIdentifier deviceObjectIdentifier, Address deviceAddress) {
        this.deviceObjectIdentifier = deviceObjectIdentifier;
        this.deviceAddress = deviceAddress;
    }

    @Override
    public void write(ByteQueue queue) {
        write(queue, deviceObjectIdentifier);
        write(queue, deviceAddress);
    }

    public AddressBinding(ByteQueue queue) throws BACnetException {
        deviceObjectIdentifier = read(queue, ObjectIdentifier.class);
        deviceAddress = read(queue, Address.class);
    }

    public ObjectIdentifier getDeviceObjectIdentifier() {
        return deviceObjectIdentifier;
    }

    public Address getDeviceAddress() {
        return deviceAddress;
    }

    @Override
    public int hashCode() {
        final int PRIME = 31;
        int result = 1;
        result = PRIME * result + ((deviceAddress == null) ? 0 : deviceAddress.hashCode());
        result = PRIME * result + ((deviceObjectIdentifier == null) ? 0 : deviceObjectIdentifier.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final AddressBinding other = (AddressBinding) obj;
        if (deviceAddress == null) {
            if (other.deviceAddress != null)
                return false;
        }
        else if (!deviceAddress.equals(other.deviceAddress))
            return false;
        if (deviceObjectIdentifier == null) {
            if (other.deviceObjectIdentifier != null)
                return false;
        }
        else if (!deviceObjectIdentifier.equals(other.deviceObjectIdentifier))
            return false;
        return true;
    }
}
